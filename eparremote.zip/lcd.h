void clockLCD(uint8_t arg);
void com(uint8_t command);
void wrt(const uint8_t *FlashLoc);
void wrtr(char *cbuf);
void wrtc(char chr);
uint8_t hex(uint8_t num);
