void cur_rel();
void cur_code();
void cur_freq();
void cur_span();
void cur_zone();

void FE_DIGIT();
void FE_REL();
void FE_CODE();
void FE_ZONE();
void FE_XMIT();

void FC_FREQ();
void FC_SPAN();
void FC_REL();
void FC_CODE();
void FC_ZONE();
void FC_XMIT();

void FLE_FREQ();
void FLE_SPAN();
void FLE_REL();
void FLE_CODE();
void FLE_ZONE();
void FLE_XMIT();

void FRE_FREQ();
void FRE_SPAN();
void FRE_REL();
void FRE_CODE();
void FRE_ZONE();
void FRE_XMIT();

void FD_FREQ();
void FD_SPAN();
void FD_REL();
void FD_CODE();
void FD_ZONE();
void FD_XMIT();

void FS_FREQ();
void FS_SPAN();
void FS_REL();
void FS_CODE();
void FS_ZONE();
void FS_XMIT();
