void update(uint32_t freq, uint8_t ph);
void EPAR_TX(uint8_t citycode, uint8_t zone, uint8_t relay, uint8_t state, uint8_t reverse, uint8_t rep);
void Up();
void DOwn();
